import os
import json
import openai

client = openai.OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

SYSTEM_PROMPT = """You are an intelligent email assistant. Analyze emails and decide the best action.

Think step by step (internally):
1. What is the email about?
2. Is it urgent?
3. Does it require scheduling?
4. Does it need a reply?
5. Is it spam?

Few-shot examples:
- Email about urgent deadline → flag_urgent
- Email requesting a meeting → schedule_meeting
- Email asking a question → reply
- Promotional/spam email → archive
- Unclear intent → request_info

Always respond with STRICT JSON only, no markdown, no extra text:
{
  "action_type": "<flag_urgent|schedule_meeting|reply|archive|request_info>",
  "content": "<drafted reply or action description>",
  "proposed_time": "<ISO datetime or empty string>"
}"""

FEW_SHOT_EXAMPLES = [
    {
        "role": "user",
        "content": json.dumps({
            "sender": "boss@company.com",
            "subject": "URGENT: Report due today",
            "body": "I need the Q3 report by 5 PM today, no exceptions."
        })
    },
    {
        "role": "assistant",
        "content": json.dumps({
            "action_type": "flag_urgent",
            "content": "This email has been flagged as urgent. The Q3 report is due by 5 PM today.",
            "proposed_time": ""
        })
    },
    {
        "role": "user",
        "content": json.dumps({
            "sender": "client@acme.com",
            "subject": "Can we schedule a call?",
            "body": "I'd like to discuss the project. Are you free tomorrow afternoon?"
        })
    },
    {
        "role": "assistant",
        "content": json.dumps({
            "action_type": "schedule_meeting",
            "content": "Hi, thank you for reaching out! I'd be happy to connect. I've scheduled a meeting for tomorrow afternoon. Looking forward to discussing the project with you.",
            "proposed_time": "2025-07-15T14:00:00"
        })
    },
    {
        "role": "user",
        "content": json.dumps({
            "sender": "promo@store.com",
            "subject": "50% OFF everything this weekend!",
            "body": "Don't miss our biggest sale of the year! Shop now for amazing deals."
        })
    },
    {
        "role": "assistant",
        "content": json.dumps({
            "action_type": "archive",
            "content": "Promotional email archived automatically.",
            "proposed_time": ""
        })
    }
]


def get_action(state: dict) -> dict:
    """
    Analyze an email state and return the recommended action.
    
    Args:
        state: dict with keys: sender, subject, body, priority (optional)
    
    Returns:
        dict with keys: action_type, content, proposed_time
    """
    fallback = {
        "action_type": "reply",
        "content": "Thank you for your email. I will get back to you shortly.",
        "proposed_time": ""
    }

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        fallback["content"] = "[API key missing] " + fallback["content"]
        return fallback

    try:
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        messages.extend(FEW_SHOT_EXAMPLES)
        messages.append({
            "role": "user",
            "content": json.dumps({
                "sender": state.get("sender", "unknown"),
                "subject": state.get("subject", ""),
                "body": state.get("body", "")
            })
        })

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0.2,
            max_tokens=400
        )

        raw = response.choices[0].message.content.strip()
        # Strip markdown code fences if present
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        result = json.loads(raw)

        # Validate required keys
        for key in ["action_type", "content", "proposed_time"]:
            if key not in result:
                result[key] = fallback[key]

        return result

    except json.JSONDecodeError as e:
        fallback["content"] = f"[JSON parse error] {fallback['content']}"
        return fallback
    except openai.APIConnectionError:
        fallback["content"] = "[Connection error] " + fallback["content"]
        return fallback
    except openai.AuthenticationError:
        fallback["content"] = "[Invalid API key] " + fallback["content"]
        return fallback
    except openai.RateLimitError:
        fallback["content"] = "[Rate limit exceeded] " + fallback["content"]
        return fallback
    except Exception as e:
        fallback["content"] = f"[Error: {str(e)}] {fallback['content']}"
        return fallback
